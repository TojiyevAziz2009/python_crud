import telebot
from telebot import types

TOKEN = "bot token"  
bot = telebot.TeleBot(TOKEN)

user_carts = {}
last_selected_foods = {}


food_menu = {
    "Setlar": ["Set Max", "Set Mini"],
    "Lavash": ["Lavash Classic", "Lavash Cheese"],
    "Shaurma": ["Shaurma Oddiy", "Shaurma Achchiq"],
    "Burger": ["Burger King", "Burger Chicken"],
    "Hot-Dog": ["Hot-Dog Classic", "Hot-Dog Cheese"],
    "Ichimliklar": ["Coca-Cola", "Fanta"]
}

@bot.message_handler(commands=['start'])
def welcome(message):
    user_carts[message.chat.id] = []
    bot.send_message(message.chat.id, "EVOS | Dastavka botiga xush kelibsiz!")
    markup = types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
    button = types.KeyboardButton("📞 Telefon raqamni yuborish", request_contact=True)
    markup.add(button)
    bot.send_message(message.chat.id, "Telefon raqamingizni yuboring yoki +998XX XXX XX XX ko'rinishida yozing.", reply_markup=markup)

@bot.message_handler(content_types=['contact'])
def handle_contact(message):
    user_carts.setdefault(message.chat.id, [])
    bot.send_message(message.chat.id, "📱 Telefon raqamingiz qabul qilindi ✅")
    show_main_menu(message)

def show_main_menu(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.add(
        types.KeyboardButton("🍽 Menyu"),
        types.KeyboardButton("📋 Mening buyurtmalarim"),
        types.KeyboardButton("📩 Savat"),
        types.KeyboardButton("📞 Aloqa"),
        types.KeyboardButton("✉️ Xabar yuborish"),
        types.KeyboardButton("⚙️ Sozlamalar")
    )
    bot.send_message(message.chat.id, "🛒 Asosiy Menyu:", reply_markup=markup)

def get_category_keyboard():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    for category in food_menu.keys():
        markup.add(types.KeyboardButton(f"{category}"))
    markup.add(types.KeyboardButton("🔙 Orqaga"))
    return markup

def get_food_selection_buttons():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(
        types.KeyboardButton("1️⃣ 1-taom"),
        types.KeyboardButton("2️⃣ 2-taom"),
        types.KeyboardButton("🔙 Orqaga")
    )
    return markup

@bot.message_handler(func=lambda msg: msg.text == "🍽 Menyu")
def show_menu(message):
    bot.send_message(message.chat.id, "📋 Kategoriyalardan birini tanlang:", reply_markup=get_category_keyboard())

@bot.message_handler(func=lambda msg: msg.text in food_menu.keys())
def handle_category(message):
    chat_id = message.chat.id
    category = message.text

    user_carts.setdefault(chat_id, [])

    foods = food_menu[category]
    last_selected_foods[chat_id] = foods  

    bot.send_message(chat_id,
        f"{category} turidan tanlang:\n1. {foods[0]}\n2. {foods[1]}",
        reply_markup=get_food_selection_buttons()
    )

@bot.message_handler(func=lambda msg: msg.text == "1️⃣ 1-taom")
def order_first_item(message):
    chat_id = message.chat.id
    if chat_id in last_selected_foods:
        food = last_selected_foods[chat_id][0]
        user_carts[chat_id].append(food)
        bot.send_message(chat_id, f"✅ \"{food}\" savatga qo‘shildi.")
    else:
        bot.send_message(chat_id, "❌ Iltimos, avval kategoriya tanlang.")

@bot.message_handler(func=lambda msg: msg.text == "2️⃣ 2-taom")
def order_second_item(message):
    chat_id = message.chat.id
    if chat_id in last_selected_foods:
        food = last_selected_foods[chat_id][1]
        user_carts[chat_id].append(food)
        bot.send_message(chat_id, f"✅ \"{food}\" savatga qo‘shildi.")
    else:
        bot.send_message(chat_id, "❌ Iltimos, avval kategoriya tanlang.")

@bot.message_handler(func=lambda msg: msg.text == "📋 Mening buyurtmalarim")
def handle_orders(message):
    orders = user_carts.get(message.chat.id, [])
    if orders:
        bot.send_message(message.chat.id, "🧾 Buyurtmalaringiz:\n" + "\n".join(orders))
    else:
        bot.send_message(message.chat.id, "🧾 Sizda hozircha buyurtmalar mavjud emas.")

@bot.message_handler(func=lambda msg: msg.text == "📩 Savat")
def handle_cart(message):
    orders = user_carts.get(message.chat.id, [])
    if orders:
        bot.send_message(message.chat.id, "🛍 Savatingiz:\n" + "\n".join(orders))
    else:
        bot.send_message(message.chat.id, "🛍 Savatingiz hozircha bo‘sh.")

@bot.message_handler(func=lambda msg: msg.text == "📞 Aloqa")
def handle_contact_info(message):
    bot.send_message(message.chat.id, "📞 Aloqa uchun:\n☎️ 1234\n🌐 https://evos.uz")

@bot.message_handler(func=lambda msg: msg.text == "✉️ Xabar yuborish")
def handle_feedback(message):
    bot.send_message(message.chat.id, "✍️ Fikr-mulohazalaringizni yozing:")

@bot.message_handler(func=lambda msg: msg.text == "⚙️ Sozlamalar")
def handle_settings(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(
        types.KeyboardButton("🗑 Ma'lumotlarni tozalash"),
        types.KeyboardButton("🔙 Orqaga qaytish")
    )
    bot.send_message(message.chat.id, "📋 Sozlamalar bo‘limi:", reply_markup=markup)

@bot.message_handler(func=lambda msg: msg.text == "🗑 Ma'lumotlarni tozalash")
def clear_data(message):
    user_carts[message.chat.id] = []
    last_selected_foods.pop(message.chat.id, None)
    bot.send_message(message.chat.id, "🗑 Ma'lumotlar tozalandi.")
    welcome(message)

@bot.message_handler(func=lambda msg: msg.text == "🔙 Orqaga" or msg.text == "🔙 Orqaga qaytish")
def handle_back(message):
    show_main_menu(message)
    bot.send_message(message.chat.id, "🔙 Asosiy menyuga qaytdingiz.")

@bot.message_handler(func=lambda msg: True)
def handle_any_text(message):
    bot.send_message(message.chat.id, "✅ Xabaringiz qabul qilindi!")

bot.polling()
